document.addEventListener("DOMContentLoaded", () => {
    const overlay = document.getElementById("transitionOverlay");
    const transitionVideo = document.getElementById("transitionVideo");
    const iframeContainer = document.getElementById("iframeContainer");
    const pageContent = document.querySelector(".page-content");
  
    // Если на этой странице нет данных элементов — выходим
    if (!overlay || !transitionVideo || !iframeContainer || !pageContent) {
      return;
    }
  
    // cutPoint (сек), когда мы «подменяем» старую страницу на iframe
    const CUT_POINT = 1.0;
    let cutDone = false;
    let pendingUrl = null;
  
    // Когда видео заканчивается — делаем настоящий переход
    transitionVideo.addEventListener("ended", () => {
      console.log("Видео закончено, переходим на:", pendingUrl);
      if (pendingUrl) {
        window.location.href = pendingUrl;
      }
    });
  
    // Следим за timeupdate
    transitionVideo.addEventListener("timeupdate", () => {
      //console.log("currentTime =", transitionVideo.currentTime);
      if (!cutDone && transitionVideo.currentTime >= CUT_POINT) {
        cutDone = true;
        console.log("Достигли cutPoint, меняем страницу под транзишном...");
  
        // Скрываем старый контент
        pageContent.style.display = "none";
  
        // Показываем iframe (новая страница)
        iframeContainer.style.display = "block";
        iframeContainer.innerHTML = `
          <iframe
            src="${pendingUrl}"
            style="border:none; width:100%; height:100%;"
          ></iframe>
        `;
      }
    });
  
    // Находим ссылки
    const links = document.querySelectorAll(".nav-link");
    links.forEach(link => {
      link.addEventListener("click", e => {
        e.preventDefault();
        pendingUrl = link.getAttribute("href");
        console.log("Клик! Запускаем транзишн. Потом перейдём на:", pendingUrl);
  
        // Сбрасываем
        cutDone = false;
  
        // Показываем оверлей и видео
        overlay.style.display = "block";
        transitionVideo.currentTime = 0;
        transitionVideo.play().then(() => {
          console.log("Транзишн начался...");
        }).catch(err => {
          console.error("Ошибка при play:", err);
        });
      });
    });
  });
  